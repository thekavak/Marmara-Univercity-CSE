#include <stdio.h>
int arraySize = 5;
int count = 0;


 void swapHeap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
  }

  void heapify(int arr[], int n, int i) {
    // Find largest among root, left child and right child
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest])
      largest = left;

    if (right < n && arr[right] > arr[largest])
      largest = right;

    // swapHeap and continue heapifying if root is not largest
    if (largest != i) {
      swapHeap(&arr[i], &arr[largest]);
      heapify(arr, n, largest);
    }
    count++;
  }

  // Main function to do heap sort
  void heapSort(int arr[], int n) {
    // Build max heap
    int i;
    for ( i = n / 2 - 1; i >= 0; i--)
      heapify(arr, n, i);

    // Heap sort
    for ( i = n - 1; i >= 0; i--) {
      swapHeap(&arr[0], &arr[i]);

      // Heapify root element to get highest element at root again
      heapify(arr, i, 0);
    }
  }

  void countingSort(int array[], int size) {
  int output[size];

  // Find the largest element of the array
  int max = array[0];
  int i;
  for ( i = 1; i < size; i++) {
    if (array[i] > max)
      max = array[i];

  }

  int cnt[max];

  // Initialize count array with all zeros.
  for ( i = 0; i <= max; ++i) {
    cnt[i] = 0;

  }

  // Store the count of each element
  for (i = 0; i < size; i++) {
    cnt[array[i]]++;

  }

  // Store the cummulative count of each array
  for (i = 1; i <= max; i++) {
    cnt[i] += cnt[i - 1];

  }

  // Find the index of each element of the original array in count array, and
  // place the elements in output array
  for (i = size - 1; i >= 0; i--) {
    output[cnt[array[i]] - 1] = array[i];
    cnt[array[i]]--;
 count++;
  }

  // Copy the sorted elements into original array
  for (i = 0; i < size; i++) {
    array[i] = output[i];

  }
}


void swapQuick(int* arr, int i, int j) {


    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}

int partition(int *arr, long low,long high)
{
    int pivot = arr[low];
    int i = 0;
    int j = high + 1;

	
	
    while (j>i) {
        // Find leftmost element greater
        // than or equal to pivot
        
        
        
        do {
            i++;
            
          
        } while (arr[i] <= pivot);

        // Find rightmost element smaller
        // than or equal to pivot
        do {
            j--;
        	count++;
        } while (arr[j] > pivot);

        swapQuick(arr,i,j);
        
        
    }
    swapQuick(arr,i,j);
    swapQuick(arr,low,j);
    
    
    return j;
}
int medianOfThreePartition(int arr[],int low, int high) {
    int x=arr[low];
    int y=arr[high];
    int middle=(high+low)/2;
    int z=arr[middle];
    int pivotIndex;
    int pivot;

    int median = middleOfThree(x,y,z);
    if (median==x){pivotIndex=low;}
    else if(median==y){pivotIndex=high;}
    else {pivotIndex=middle;}
    swapQuick(arr,low,pivotIndex);

    return partition(arr,low,high);


}

int middleOfThree(int a, int b, int c)
{
    // Checking for b
    if ((a < b && b < c) || (c < b && b < a))
        return b;

        // Checking for a
    else if ((b < a && a < c) || (c < a && a < b))
        return a;

    else
        return c;
}



void quickSortHoares(int arr[], long low, long high)
{
	count++;
    if (low >= high) {return;}
    /* pi is partitioning index,
     arr[p] is now at right place */
    int pi = partition(arr, low, high);
	
    // Separately sort elements before
    // partition and after partition
    quickSortHoares(arr, low, pi-1);
    quickSortHoares(arr, pi + 1, high);


}

void quickSortMiddleOf3(int arr[], long low, long high)
{
    if (low >= high) {return;}
    /* pi is partitioning index,
     arr[p] is now at right place */
    int pi = medianOfThreePartition(arr, low, high);

    // Separately sort elements before
    // partition and after partition
    quickSortMiddleOf3(arr, low, pi-1);
    quickSortMiddleOf3(arr, pi + 1, high);


}


//MergeSort Algorithm 3.1
void merge(int arr[], int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;
 
  
    int L[n1], R[n2];
 
    for (i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];
 
    i = 0; // Initial index of first subarray
    j = 0; // Initial index of second subarray
    k = l; // Initial index of merged subarray
    while (i < n1 && j < n2) {
    	count++;
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        }
        else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
 
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
 
   
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

//MergeSort Algorithm 3.2
void mergeSort(int arr[], int l, int r)
{
    if (l < r) {
       
        int m = l + (r - l) / 2;
 
      
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
 
        merge(arr, l, m, r);
    }
}


//Binary InsertionSort Algorithm 2.2
int binarySearch(int a[], int item, int low, int high)
{
	count++;
    if (high <= low)
    {
    	count--;
    	return (item > a[low])?  (low + 1): low;
	}
       
  
    int mid = (low + high)/2;
  
    if(item == a[mid])
        return mid+1;
  
    if(item > a[mid])
        return binarySearch(a, item, mid+1, high);
    return binarySearch(a, item, low, mid-1);
    
}


//Binary InsertionSort Algorithm 2.1
 insertionSortBinary(int arr[], int n)
{
	
/*	int ab;
	
	for(ab=0; ab<n; ab++)
	{
		printf("%d ",arr[ab]);
	}
	printf("\n \n \n bitti \n \n");
	
*/	
    int i, loc, j, k, selected;
  
    for (i = 1; i < n; ++i)
    {
        j = i - 1;
        selected = arr[i];
  
        // find location where selected sould be inseretd
        loc = binarySearch(arr, selected, 0, j);
  
        // Move all elements after location to create space
        while (j >= loc)
        {
            arr[j+1] = arr[j];
            j--;
            count = count +2;
        }
        arr[j+1] = selected;
    
    }

}


//InsertionSort Algorithm 1.0
int insertionSort(int arr[], int n)
{
	
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;
 
        /* Move elements of arr[0..i-1], that are
          greater than key, to one position ahead
          of their current position */
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
          count= count +2;
        }
        
        count++;
        arr[j + 1] = key;
    }
    

}


 calculateBasic(int arr[], int size, int flag)
{

	int *list1,*list2,*list3,*list4,*list5,*list6,*list7;
	list1=(int *)malloc(size*sizeof(int));
		list2=(int *)malloc(size*sizeof(int));
			list3=(int *)malloc(size*sizeof(int));
				list4=(int *)malloc(size*sizeof(int));
					list5=(int *)malloc(size*sizeof(int));
						list6=(int *)malloc(size*sizeof(int));
							list7=(int *)malloc(size*sizeof(int));
							
				int k;
				for(k =0; k<size; k++)
				{
					list1[k] = arr[k];
					list2[k] = arr[k];
					list3[k] = arr[k];
					list4[k] = arr[k];
					list5[k] = arr[k];
					list6[k] = arr[k];
					list7[k] = arr[k];
				}
								
	
	
	count = 0;
    insertionSort(list1, size);
    printf("insertionSort count: %d \n", count);
   
    
    count = 0;
    insertionSortBinary(list2, size);
    printf("insertionSortBinary count: %d \n", count);
    
    
    count = 0;
    mergeSort(list3, 0, size - 1);
    printf("mergeSort count: %d \n", count);
    
    
    count = 0;
   	quickSortHoares(list4,0,size-1);
    printf("quickSortHoares count: %d \n", count);
    
    
    count = 0;
   	quickSortMiddleOf3(list5,0,size-1);
    printf("quickSortMiddleOf3 count: %d \n", count);
        

 	count = 0;
   	heapSort(list6,size-1);
    printf("heapSort count: %d \n", count);
    
    
    count = 0;
 	countingSort(list7,size+1);
    printf("countingSort count: %d \n", count);

   
}


 

createNewLinearList(int size)
{
	int *arr;
	int j;
	arr=(int *)malloc(size*sizeof(int));
	
	for(j =0; j<size; j++)
	{
		arr[j] = j+1;
	}
	
	//flag = 0 for linear List;
	calculateBasic(arr,size,0);
	free(arr);
	
}


createNewReverseList(int size)
{
	int *arr;
	int j;
	int tempSize = size;
	arr=(int *)malloc(size*sizeof(int));
	
	for(j =0; j<size; j++)
	{
		arr[j] = tempSize-j;
	}
	
	calculateBasic(arr,size,1);	
	
}


createNewRandomList(int size)
{
	int *arr;
	int i;
	int tempSize = size;
	arr=(int *)malloc(size*sizeof(int));

    for (i = 0; i < tempSize; i++) {
        int num = (rand() %
           (8000 - 1 + 1)) + 1;
           arr[i] = num;
        //printf("%d - %d \n ", i,num);
    }
	
	calculateBasic(arr,size,1);	
	
}



int main(){
	int totalSizes[5] = {1000,2000,4000,8000,10000};
	int i,j,k;
	
	printf("\n------------------------------------------------ \n Linear Array");	
	printf("\n------------------------------------------------ \n");	
	
	 for(i = 0; i<arraySize; i++){
		printf("\n\n----------------------\n Array size: %d \n----------------------\n\n",  totalSizes[i]);

		createNewLinearList(totalSizes[i]);		
	}

	printf("\n\n\n------------------------------------------------ \n Reverse Array");	
	printf("\n------------------------------------------------ \n");	
	
	for(j = 0; j<arraySize; j++){
		printf("\n\n----------------------\n Array size: %d \n----------------------\n\n",  totalSizes[j]);
		createNewReverseList(totalSizes[j]);	
			
	}
	
	
	printf("\n\n\n------------------------------------------------ \n Random Array");	
	printf("\n------------------------------------------------ \n");	
	
	for(k = 0; k<arraySize; k++){
		printf("\n\n----------------------\n Array size: %d \n----------------------\n\n", totalSizes[k]);
		createNewRandomList(totalSizes[k]);	
			
	}
	
	
	
}
